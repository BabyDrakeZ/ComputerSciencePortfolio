// CS111_Parallel_Arrays.cpp : This file contains the 'main' function. Program execution begins and ends there.
// How to Use Arrays -- Week 2 Sem 1;
// Random Number Initialization

#include <iostream>
#include <string>


#define ARRAY_LENGTH 2
#define NOT_FOUND -1

using namespace std;


void initArrays(int arr[], string n[], const int size); //arrays are always pass by refrence
void printData(int ids[], string names[], const int size);
void getStudentDataFromTTY(int ids[], string names[], const int size);

//precondition: int arr[] is the the list of integers size is size of array
//postcondition: sums the contents of the array and puts the sum in arr[0]
//void sumArrays(int arr[], const int size);

//precondition: int z[] are the IDS...
int searchByNameForID(const int z[], const string n[], const int size, const string target);

string searchByIDForName(const int ids[], const string names[], const int size, const int target);

//precondition: s[] is an array of strings, is[] is an array of corresponding ints, target is search target
//postcondition: return id of target or NOT_FOUND if not found
int search(string s[], int is[], int const size, string target);




int main()
{
    srand(time(NULL));  //initialized the random number generator--CALL THIS ONLY ONCE //seed rand
    int ids[ARRAY_LENGTH]; //= {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    string names[ARRAY_LENGTH];
    string name = "";
    int id = -1;
    initArrays(ids, names, ARRAY_LENGTH);
    getStudentDataFromTTY(ids, names, ARRAY_LENGTH);
    //sumArray(ints, ARRAY_LENGTH);
    printData(ids, names, ARRAY_LENGTH);

    //cout << "Enter a name or id you would like to search for: ";
    //cin >> name;
    //search(ids, names, ARRAY_LENGTH, name);

    cout << "Enter a name you would like to search for an id with: ";
    cin >> name;
    id = searchByNameForID(ids, names, ARRAY_LENGTH, name);
    if (id != NOT_FOUND)
        cout << "Id found: " << id << endl;
    else
        cout << "Index Failed" << endl;
    
    cout << "Enter an id you would like to search for a name with: ";
    cin >> id;
    name = searchByIDForName(ids, names, ARRAY_LENGTH, id);
    if (name != "NOT_FOUND")
        cout << "Name found: " << name << endl;
    else
        cout << "Index Failed" << endl;


    return 0;
}

void initArrays(int arr[], string n[], const int size) {
    for (int i = 0; i < size; i++) {
        arr[i] = rand() % 100; //0's are not a good number, pick values that will break things, like random numbers
        n[i] = "Undefined";
    }
}
void printData(int ids[], string names[], const int size) {
    for (int i = 0; i < size; i++) {
        cout << "Student " << names[i] << " has ID: " << ids[i] << "\n";
    }
}

void getStudentDataFromTTY(int ids[], string names[], const int size) {
    cout << "Please input " << size << " names and ids" << "\n";
    for (int i = 0; i < size; i++) {
        string name = "";
        int id = 0;
        cout << "Input name and id: ";
        cin >> name >> id;
        ids[i] = id;
        names[i] = name;
    }
}
int searchForIndex(const string n[], const int is[], const int size, const string target){
    for (int i = 0; i < size; i++) {
        if (n[i] == target || (to_string(is[i]) == target)) {
            //cout << "Search found: " << n[i] << " " << is[i] << "\n";
            return i;
        }
    }
    return NOT_FOUND;
}

string searchByIDForName(const int ids[], const string names[], const int size, const int target) {
    for (int i = 0; i < size; i++) {
        if (ids[i] == target) {
            return names[i];
        }
    }
    return "NOT_FOUND";
}

int searchByNameForID(const int ids[], const string names[], const int size, const string target) {
    //int index = searchForIndex(n, z, size, target);
    //return z[index];
    for (int i = 0; i < size; i++) {
        if (names[i] == target) {
            //cout << "Search found: " << names[i] << " " << ids[i] << "\n";
            return ids[i];
        }
    }
    return NOT_FOUND;
}

//void sumArray(int arr[], const int size) {
//    for (int i = 1; i < size; i++) {
//        arr[0] += arr[i];
//    }
//}