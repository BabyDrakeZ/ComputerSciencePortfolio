#include "ExamScore.h"

ExamScore::ExamScore() {
	score = -1;
	name = "~Unassigned";
	next = NULL;
}
ExamScore::ExamScore(float score, std::string name) {
	this->score = score;
	this->name = name;
	next = NULL;
}
ExamScore::~ExamScore() {
	std::cout << "Deleted " << name << "\n";
}
float ExamScore::getScore() {
	return score;
}
void ExamScore::setScore(float _score) {
	score = _score;
}
std::string ExamScore::getName() {
	return name;
}
void ExamScore::setName(std::string _name) {
	name = _name;
}
ExamScore* ExamScore::getNext() {
	return next;
}
void ExamScore::setNext(ExamScore* _next) {
	next = _next;
}
void ExamScore::print() {
	std::cout << "Student: " << name << ", Scored: " << score << "\n";
}