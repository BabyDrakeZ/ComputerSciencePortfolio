
#include "ExamScore.h"
#include <iostream>

//postcondition: adds an tPtr (tempPointer) to a linked list after head
void headInsert(exPtr &head, exPtr tPtr);

void deleteList(exPtr& head);

int main(void){
	exPtr rPtr = new ExamScore(15.5, "Test");
	ExamScore r = ExamScore();
	r.setScore(0.1);
	r.setName("Summer");
	std::cout << "Pointer values\n";
	rPtr->print();
	std::cout << "Objects values\n";
	r.print();
	delete rPtr;
	rPtr = NULL;
	exPtr head = NULL;
	for (float i = 8; i <= 16; i = i*2)
	{
		headInsert(head, new ExamScore(i, "Joe"));
	}
	deleteList(head);
	//note r appears to be deleted automatically.
	return 0;
}

void headInsert (exPtr &head, exPtr tPtr){
	tPtr->setNext(head);
	head = tPtr;
	tPtr = NULL;
}
void deleteList(exPtr& head) {
	if (head != NULL){
		exPtr temp = head;
		head = head->getNext();
		delete temp;
		temp = NULL;
		deleteList(head);
	}
}