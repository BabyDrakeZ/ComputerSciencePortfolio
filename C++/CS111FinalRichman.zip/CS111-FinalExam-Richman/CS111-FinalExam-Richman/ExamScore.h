#pragma once

#include <iostream>
#include <string>

class ExamScore {
private:
	float score;
	std::string name;
	ExamScore *next;
public:
	ExamScore();
	ExamScore(float score, std::string name);
	~ExamScore();
	float getScore();
	void setScore(float _score);
	std::string getName();
	void setName(std::string _name);
	ExamScore* getNext();
	void setNext(ExamScore* _next);
	void print();
};

typedef ExamScore* exPtr;